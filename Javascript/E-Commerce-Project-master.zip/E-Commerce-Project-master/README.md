# Shoplane - A Place For Shoppong

[Live Demo](https://shoplane.netlify.app/)

This is an E-Commerce webbsite that I have created  when I was in the mid of JavaScript. I have used the HTML, CSS and JavaScript to create this project. The purpose of this project to get hands on in working with javascriptis. 

I have created the Responsive Navbar for the website which works perfectly on each screen sizes. Th Banner Carousel on the top of the website was created using an external library called [slick](https://kenwheeler.github.io/slick/). 

The website fetches all the product data from an API to display all the products. I have used the local-storage of the browser the store the Cart Count and Cart Items.

I have learned many new this while working on this project and also encountered many error and problems.

*This project is very intresting and challenging...*

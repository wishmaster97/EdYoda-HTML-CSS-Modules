console.log('Script Loaded!!')

let mPara = document.getElementById('para');
let mSpan = document.getElementById('span');
let mImg = document.getElementById('img-food');

mPara.onclick = function() {
    alert('Para clicked!!')
}

mSpan.onclick = function() {
    alert('Span clicked!!')
}

mImg.onclick = function() {
    alert('Image clicked!!')
}